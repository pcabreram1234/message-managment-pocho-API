const getCurrentDate = () => {
  const date = new Date();
  return date;
};

module.exports = { getCurrentDate };
