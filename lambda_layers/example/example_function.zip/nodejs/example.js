const printHola = () => { 

    console.log('Hola desde la función printHola');
}

module.exports = { printHola }; 